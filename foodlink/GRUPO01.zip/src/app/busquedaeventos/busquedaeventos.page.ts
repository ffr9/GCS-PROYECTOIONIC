import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-busquedaeventos',
  templateUrl: './busquedaeventos.page.html',
  styleUrls: ['./busquedaeventos.page.scss'],
})
export class BusquedaeventosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
