import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recompensas',
  templateUrl: './recompensas.page.html',
  styleUrls: ['./recompensas.page.scss'],
})
export class RecompensasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
